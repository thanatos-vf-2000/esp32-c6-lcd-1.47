/*
 * eez-framework
 *
 * MIT License
 * Copyright 2024 Envox d.o.o.
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#pragma once

#include <stdint.h>
#include <stdlib.h>

#ifdef EEZ_PLATFORM_STM32
#include <fatfs.h>
#endif

#if defined(EEZ_PLATFORM_SIMULATOR) || defined(__EMSCRIPTEN__)
#include <filesystem>
#endif

#define FILE_READ 0x01
#define FILE_WRITE 0x02
#define FILE_OPEN_EXISTING 0x00
#define FILE_CREATE_NEW 0x04
#define FILE_CREATE_ALWAYS 0x08
#define FILE_OPEN_ALWAYS 0x10
#define FILE_OPEN_APPEND 0x30

namespace eez {

// clang-format off
enum SdFatResult {
    SD_FAT_RESULT_OK = 0,          /* (0) Succeeded */
    SD_FAT_RESULT_DISK_ERR,        /* (1) A hard error occurred in the low level disk I/O layer */
    SD_FAT_RESULT_INT_ERR,         /* (2) Assertion failed */
    SD_FAT_RESULT_NOT_READY,       /* (3) The physical drive cannot work */
    SD_FAT_RESULT_NO_FILE,         /* (4) Could not find the file */
    SD_FAT_RESULT_NO_PATH,         /* (5) Could not find the path */
    SD_FAT_RESULT_INVALID_NAME,    /* (6) The path name format is invalid */
    SD_FAT_RESULT_DENIED,          /* (7) Access denied due to prohibited access or directory full */
    SD_FAT_RESULT_EXIST,           /* (8) Access denied due to prohibited access */
    SD_FAT_RESULT_INVALID_OBJECT,  /* (9) The file/directory object is invalid */
    SD_FAT_RESULT_WRITE_PROTECTED, /* (10) The physical drive is write protected */
    SD_FAT_RESULT_INVALID_DRIVE,   /* (11) The logical drive number is invalid */
    SD_FAT_RESULT_NOT_ENABLED,     /* (12) The volume has no work area */
    SD_FAT_RESULT_NO_FILESYSTEM,   /* (13) There is no valid FAT volume */
    SD_FAT_RESULT_MKFS_ABORTED,    /* (14) The f_mkfs() aborted due to any problem */
    SD_FAT_RESULT_TIMEOUT,         /* (15) Could not get a grant to access the volume within defined period */
    SD_FAT_RESULT_LOCKED,          /* (16) The operation is rejected according to the file sharing policy */
    SD_FAT_RESULT_NOT_ENOUGH_CORE, /* (17) LFN working buffer could not be allocated */
    SD_FAT_RESULT_TOO_MANY_OPEN_FILES, /* (18) Number of open files > _FS_LOCK */
    SD_FAT_RESULT_INVALID_PARAMETER,    /* (19) Given parameter is invalid */
};
// clang-format on

struct FileInfo {
    FileInfo();

    SdFatResult fstat(const char *filePath);

    operator bool(); // fname[0]
    bool isDirectory();
    void getName(char *name, size_t size);
    size_t getSize();
    bool isHiddenOrSystemFile();

    int getModifiedYear();
    int getModifiedMonth();
    int getModifiedDay();

    int getModifiedHour();
    int getModifiedMinute();
    int getModifiedSecond();

#if defined(EEZ_PLATFORM_STM32)
    FILINFO m_fno;
#else
    std::filesystem::directory_entry m_entry;
#endif
};

struct Directory {
    Directory();
    ~Directory();

    void close();

    SdFatResult findFirst(const char *path, FileInfo &fileInfo);
    SdFatResult findNext(FileInfo &fileInfo);

#if defined(EEZ_PLATFORM_STM32)
    DIR m_dj;
#else
    std::filesystem::directory_iterator m_it;
#endif
};

class File {
    File(const File &file);
    const File &operator=(const File &file);

  public:
    File();

    bool open(const char *path, uint8_t mode = FILE_READ);

    ~File();
    bool close();

    bool isOpen();

    bool truncate(uint32_t length);

    bool available();
    size_t size();
    bool seek(uint32_t pos);
    size_t tell();
    int peek();
    int read();
    size_t read(void *buf, uint32_t nbyte);
    size_t write(const void *buf, size_t size);
    bool sync();

    void print(float value, int numDecimalDigits);
    void print(char value);

  private:
    bool m_isOpen{false};
#if defined(EEZ_PLATFORM_SIMULATOR) || defined(__EMSCRIPTEN__)
    FILE *m_fp{NULL};
#else
    FIL m_file;
#endif
};

class SdFat {
  public:
    bool mount(int *err);
    void unmount();
    bool exists(const char *path);
    bool rename(const char *sourcePath, const char *destinationPath);
    bool remove(const char *path);
    bool mkdir(const char *path);
    bool rmdir(const char *path);

    bool getInfo(int diskDriveIndex, uint64_t &usedSpace, uint64_t &freeSpace);
};

char *getConfFilePath(const char *file_name);

} // namespace eez
