This folder is for LVGL SquareLine Studio

SquareLine Studio can automatically put the generated C files into `ui` folder, so that rt-thread will automatically detect them; or, as a user, you can move the generated C files into `ui` folder manually.

